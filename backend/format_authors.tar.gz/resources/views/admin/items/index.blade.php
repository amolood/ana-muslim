<x-admin-layout>
    <div class="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h2 class="text-xl font-bold text-gray-800 dark:text-white">إدارة المواد العلمية والدعوية</h2>
        <a href="{{ route('admin.items.create') }}" class="admin-btn bg-blue-600 text-white hover:bg-blue-700">
            <i class="fa-solid fa-plus ml-2"></i> إضافة مادة جديدة
        </a>
    </div>

    @if(session('success'))
        <div class="mb-4 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 p-4 rounded-xl flex items-center gap-3">
            <i class="fa-solid fa-circle-check"></i>
            {{ session('success') }}
        </div>
    @endif

    <!-- Search & Filter -->
    <div class="admin-card mb-6 p-4">
        <form action="{{ route('admin.items.index') }}" method="GET" class="flex flex-col sm:flex-row gap-4">
            <div class="flex-1">
                <input type="text" name="search" value="{{ request('search') }}" placeholder="ابحث باسم المادة..." class="w-full rounded-xl border-gray-200 bg-gray-50/50 px-4 py-2.5 text-sm focus:border-blue-500 focus:ring-blue-500 dark:border-white/10 dark:bg-white/5 dark:text-white">
            </div>
            <div class="w-full sm:w-64">
                <select name="type" class="w-full rounded-xl border-gray-200 bg-gray-50/50 px-4 py-2.5 text-sm focus:border-blue-500 focus:ring-blue-500 dark:border-white/10 dark:bg-white/5 dark:text-white">
                    <option value="">جميع الأنواع</option>
                    @foreach($types as $t)
                        <option value="{{ $t }}" {{ request('type') == $t ? 'selected' : '' }}>
                            {{ $typeMap[strtolower($t)] ?? ucfirst($t) }}
                        </option>
                    @endforeach
                </select>
            </div>
            <button type="submit" class="admin-btn bg-gray-800 text-white hover:bg-gray-700 dark:bg-white/10 dark:hover:bg-white/20">
                <i class="fa-solid fa-search ml-2"></i> بحث
            </button>
            @if(request()->has('search') || request()->has('type'))
                <a href="{{ route('admin.items.index') }}" class="admin-btn bg-red-50 text-red-600 hover:bg-red-100 dark:bg-red-900/20 dark:hover:bg-red-900/40">
                    <i class="fa-solid fa-times ml-2"></i> إلغاء
                </a>
            @endif
        </form>
    </div>

    <!-- Table -->
    <div class="admin-card overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-right text-sm">
                <thead>
                    <tr class="border-b border-gray-100 bg-gray-50/50 text-gray-500 dark:border-white/10 dark:bg-white/5 dark:text-gray-400">
                        <th class="px-6 py-4 font-medium">الصورة</th>
                        <th class="px-6 py-4 font-medium">العنوان</th>
                        <th class="px-6 py-4 font-medium">النوع</th>
                        <th class="px-6 py-4 font-medium">التصنيف</th>
                        <th class="px-6 py-4 font-medium">المؤلف/القارئ</th>
                        <th class="px-6 py-4 font-medium">الإجراءات</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-white/10">
                    @forelse($items as $item)
                        <tr class="hover:bg-gray-50/50 dark:hover:bg-white/5 transition-colors">
                            <td class="px-6 py-4">
                                @if($item->image)
                                    <img src="{{ $item->image }}" alt="صورة المادة" class="h-12 w-12 rounded-lg object-cover">
                                @else
                                    <div class="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-lg bg-gray-100 dark:bg-white/5">
                                        <i class="fa-solid fa-image text-gray-400"></i>
                                    </div>
                                @endif
                            </td>
                            <td class="px-6 py-4">
                                <span class="block max-w-[200px] truncate font-medium text-gray-800 dark:text-gray-200" title="{{ $item->title }}">{{ $item->title }}</span>
                            </td>
                            <td class="px-6 py-4">
                                <span class="inline-flex items-center gap-1.5 rounded-lg bg-amber-50 px-2.5 py-1 text-xs font-medium text-amber-600 dark:bg-amber-900/20 dark:text-amber-400">
                                    @php
                                        $displayType = $item->type;
                                        if (is_numeric($displayType) || empty(trim($displayType))) {
                                            $displayType = 'غير محدد';
                                        } else {
                                            $displayType = $typeMap[strtolower($displayType)] ?? ucfirst($displayType);
                                        }
                                    @endphp
                                    {{ $displayType }}
                                </span>
                            </td>
                            <td class="px-6 py-4">
                                <div class="flex flex-wrap gap-1">
                                    @foreach($item->categories->take(2) as $category)
                                        <span class="rounded bg-blue-50 px-2 py-0.5 text-[10px] text-blue-600 dark:bg-blue-900/20 dark:text-blue-400">
                                            {{ Str::limit($category->title, 15) }}
                                        </span>
                                    @endforeach
                                    @if($item->categories->count() > 2)
                                        <span class="rounded bg-gray-100 px-2 py-0.5 text-[10px] text-gray-600 dark:bg-white/10 dark:text-gray-400">
                                            +{{ $item->categories->count() - 2 }}
                                        </span>
                                    @endif
                                    @if($item->categories->isEmpty())
                                        <span class="text-gray-400 text-xs">-</span>
                                    @endif
                                </div>
                            </td>
                            <td class="px-6 py-4">
                                <div class="flex flex-col gap-1.5">
                                    @forelse($item->authors->take(2) as $author)
                                        <div class="flex items-center gap-1.5 text-xs font-medium text-gray-700 dark:text-gray-300" title="{{ $author->title }}">
                                            <div class="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-emerald-600 dark:bg-emerald-900/20 dark:text-emerald-400">
                                                <i class="fa-solid fa-user-pen text-[10px]"></i>
                                            </div>
                                            <span class="truncate max-w-[150px]">{{ $author->title }}</span>
                                        </div>
                                    @empty
                                        <span class="text-xs text-gray-400">-</span>
                                    @endforelse
                                    @if($item->authors->count() > 2)
                                        <div class="text-[10px] font-medium text-emerald-600 dark:text-emerald-500 bg-emerald-50 dark:bg-emerald-900/10 inline-flex items-center px-2 py-0.5 rounded-full w-fit mr-6 mt-0.5">
                                            +{{ $item->authors->count() - 2 }} آخرين
                                        </div>
                                    @endif
                                </div>
                            </td>
                            <td class="px-6 py-4">
                                <div class="flex items-center gap-2">
                                    <a href="{{ route('admin.attachments.index', ['item_id' => $item->id]) }}" class="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600 hover:bg-emerald-100 dark:bg-emerald-900/20 dark:hover:bg-emerald-900/40 transition-colors" title="المرفقات">
                                        <i class="fa-solid fa-paperclip"></i>
                                    </a>
                                    <a href="{{ route('admin.items.edit', $item->id) }}" class="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 dark:bg-blue-900/20 dark:hover:bg-blue-900/40 transition-colors" title="تعديل">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </a>
                                    <form action="{{ route('admin.items.destroy', $item->id) }}" method="POST" class="inline-block" onsubmit="return confirm('هل أنت متأكد من حذف هذه المادة؟ سيتم حذف جميع المرفقات المرتبطة بها نهائياً.');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="flex h-8 w-8 items-center justify-center rounded-lg bg-red-50 text-red-600 hover:bg-red-100 dark:bg-red-900/20 dark:hover:bg-red-900/40 transition-colors" title="حذف">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="px-6 py-8 text-center text-gray-500 dark:text-gray-400">لا توجد مواد علمية لعرضها.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        
        @if($items->hasPages())
            <div class="border-t border-gray-100 p-4 dark:border-white/10">
                {{ $items->withQueryString()->links() }}
            </div>
        @endif
    </div>
</x-admin-layout>
