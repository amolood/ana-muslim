<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AnaMuslimCategory;
use App\Models\AnaMuslimItem;

class IslamicContentController extends Controller
{
    /**
     * Get all categories with item counts.
     */
    public function getTypes(Request $request)
    {
        $lang = $request->query('language', 'ar');
        return response()->json(AnaMuslimCategory::where('language', $lang)->get());
    }

    /**
     * Get highlighted items. 
     * In this implementation, we grab highly important items or just recent ones.
     */
    public function getHighlights(Request $request)
    {
        $lang = $request->query('language', 'ar');
        $items = AnaMuslimItem::where('importance_level', '>', 0)
            ->where('source_language', $lang)
            ->orderByDesc('update_date')
            ->limit(10)
            ->get();
            
        // Fallback to recent if highlights empty
        if ($items->isEmpty()) {
            $items = AnaMuslimItem::where('source_language', $lang)
                ->orderByDesc('update_date')
                ->limit(10)
                ->get();
        }

        return response()->json($items);
    }

    /**
     * Get latest 10 items.
     */
    public function getLatest(Request $request)
    {
        $lang = $request->query('language', 'ar');
        $items = AnaMuslimItem::where('source_language', $lang)
            ->orderByDesc('add_date')
            ->limit(10)
            ->get();

        return response()->json($items);
    }

    /**
     * Get paginated items by type (e.g., 'books', 'audios').
     */
    public function getItems(Request $request, $type)
    {
        $lang = $request->query('language', 'ar');
        
        $items = AnaMuslimItem::where('type', $type)
            ->where('source_language', $lang)
            ->orderByDesc('add_date')
            ->paginate(20);

        return response()->json($items);
    }

    /**
     * Get full details of a specific item, including authors, locales, and attachments.
     */
    public function getItemDetails($id)
    {
        // Try searching by source_id first
        $item = AnaMuslimItem::with(['authors', 'attachments', 'locales'])
            ->where('source_id', $id)
            ->first();
            
        // Fallback to local auto-incrementing ID mapping
        if (!$item) {
            $item = AnaMuslimItem::with(['authors', 'attachments', 'locales'])
                ->find($id);
        }

        if (!$item) {
            return response()->json(['error' => 'Item not found'], 404);
        }

        return response()->json($item);
    }
}

