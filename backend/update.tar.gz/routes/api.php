<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\IslamicContentController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::prefix('islamic-content')->group(function () {
    Route::get('/types', [IslamicContentController::class, 'getTypes']);
    Route::get('/highlights', [IslamicContentController::class, 'getHighlights']);
    Route::get('/latest', [IslamicContentController::class, 'getLatest']);
    Route::get('/items/details/{id}', [IslamicContentController::class, 'getItemDetails']);
    Route::get('/items/{type}', [IslamicContentController::class, 'getItems']);
});
