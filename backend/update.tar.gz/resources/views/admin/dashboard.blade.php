<x-admin-layout>
    <div class="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h2 class="text-xl font-bold text-gray-800">الرئيسية</h2>
    </div>

    <!-- Stats -->
    <div class="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
        <div class="admin-card p-6 shadow-sm">
            <div class="flex items-center gap-4">
                <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-50 dark:bg-blue-900/20 text-blue-500">
                    <i class="fa-solid fa-tags text-xl"></i>
                </div>
                <div>
                    <h4 class="text-2xl font-bold text-gray-900 dark:text-white">{{ \App\Models\AnaMuslimCategory::count() }}</h4>
                    <span class="text-sm font-medium text-gray-500 dark:text-gray-400">التصنيفات</span>
                </div>
            </div>
        </div>
        
        <div class="admin-card p-6 shadow-sm">
            <div class="flex items-center gap-4">
                <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-purple-50 dark:bg-purple-900/20 text-purple-500">
                    <i class="fa-solid fa-users text-xl"></i>
                </div>
                <div>
                    <h4 class="text-2xl font-bold text-gray-900 dark:text-white">{{ \App\Models\AnaMuslimAuthor::count() }}</h4>
                    <span class="text-sm font-medium text-gray-500 dark:text-gray-400">المؤلفون والقراء</span>
                </div>
            </div>
        </div>

        <div class="admin-card p-6 shadow-sm">
            <div class="flex items-center gap-4">
                <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-50 dark:bg-emerald-900/20 text-emerald-500">
                    <i class="fa-solid fa-book-open text-xl"></i>
                </div>
                <div>
                    <h4 class="text-2xl font-bold text-gray-900 dark:text-white">{{ \App\Models\AnaMuslimItem::count() }}</h4>
                    <span class="text-sm font-medium text-gray-500 dark:text-gray-400">المواد (صوتيات/كتب)</span>
                </div>
            </div>
        </div>
    </div>
</x-admin-layout>
