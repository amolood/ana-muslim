<x-admin-layout>
    <div class="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h2 class="text-xl font-bold text-gray-800 dark:text-white">
            مرفقات المادة: {{ $item ? $item->title : 'الكل' }}
        </h2>
        <div class="flex gap-2">
            @if($item)
                <a href="{{ route('admin.items.index') }}" class="admin-btn bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-white/5 dark:text-gray-300 dark:hover:bg-white/10">
                    <i class="fa-solid fa-arrow-right ml-2"></i> العودة للمواد
                </a>
            @endif
            <a href="{{ route('admin.attachments.create', ['item_id' => $item ? $item->id : '']) }}" class="admin-btn bg-blue-600 text-white hover:bg-blue-700">
                <i class="fa-solid fa-plus ml-2"></i> إضافة مرفق
            </a>
        </div>
    </div>

    @if(session('success'))
        <div class="mb-4 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 p-4 rounded-xl flex items-center gap-3">
            <i class="fa-solid fa-circle-check"></i>
            {{ session('success') }}
        </div>
    @endif

    <!-- Table -->
    <div class="admin-card overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-right text-sm">
                <thead>
                    <tr class="border-b border-gray-100 bg-gray-50/50 text-gray-500 dark:border-white/10 dark:bg-white/5 dark:text-gray-400">
                        <th class="px-6 py-4 font-medium">الترتيب</th>
                        <th class="px-6 py-4 font-medium">المادة المرتبطة</th>
                        <th class="px-6 py-4 font-medium">النوع / الحجم</th>
                        <th class="px-6 py-4 font-medium">الرابط</th>
                        <th class="px-6 py-4 font-medium">الإجراءات</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-white/10">
                    @forelse($attachments as $attachment)
                        <tr class="hover:bg-gray-50/50 dark:hover:bg-white/5 transition-colors">
                            <td class="px-6 py-4 font-semibold text-gray-900 dark:text-white">
                                {{ $attachment->order ?? '-' }}
                            </td>
                            <td class="px-6 py-4">
                                @if($attachment->item)
                                    <a href="{{ route('admin.items.edit', $attachment->item->id) }}" class="font-medium text-blue-600 hover:underline dark:text-blue-400">
                                        {{ Str::limit($attachment->item->title, 40) }}
                                    </a>
                                @else
                                    <span class="text-gray-400">-</span>
                                @endif
                                <div class="text-xs text-gray-500 mt-1">{{ $attachment->description }}</div>
                            </td>
                            <td class="px-6 py-4">
                                <span class="inline-flex items-center gap-1.5 rounded-lg bg-indigo-50 px-2.5 py-1 text-xs font-bold uppercase text-indigo-600 dark:bg-indigo-900/20 dark:text-indigo-400">
                                    {{ $attachment->extension_type ?? 'غير محدد' }}
                                </span>
                                <div class="text-xs text-gray-500 mt-1" dir="ltr">{{ $attachment->size ?? '-' }}</div>
                            </td>
                            <td class="px-6 py-4">
                                <a href="{{ $attachment->url }}" target="_blank" class="flex items-center gap-2 text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 dark:hover:text-emerald-300">
                                    <i class="fa-solid fa-link"></i> استعراض الملف
                                </a>
                            </td>
                            <td class="px-6 py-4">
                                <div class="flex items-center gap-2">
                                    <a href="{{ route('admin.attachments.edit', $attachment->id) }}" class="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 dark:bg-blue-900/20 dark:hover:bg-blue-900/40 transition-colors" title="تعديل">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </a>
                                    <form action="{{ route('admin.attachments.destroy', $attachment->id) }}" method="POST" class="inline-block" onsubmit="return confirm('هل أنت متأكد من حذف هذا المرفق؟');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="flex h-8 w-8 items-center justify-center rounded-lg bg-red-50 text-red-600 hover:bg-red-100 dark:bg-red-900/20 dark:hover:bg-red-900/40 transition-colors" title="حذف">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="px-6 py-8 text-center text-gray-500 dark:text-gray-400">لا توجد مرفقات لعرضها.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        
        @if($attachments->hasPages())
            <div class="border-t border-gray-100 p-4 dark:border-white/10">
                {{ $attachments->withQueryString()->links() }}
            </div>
        @endif
    </div>
</x-admin-layout>
