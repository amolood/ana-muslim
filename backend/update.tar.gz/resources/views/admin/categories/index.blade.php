<x-admin-layout>
    <div class="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h2 class="text-xl font-bold text-gray-800 dark:text-white">إدارة التصنيفات</h2>
        <a href="{{ route('admin.categories.create') }}" class="admin-btn bg-blue-600 text-white hover:bg-blue-700">
            <i class="fa-solid fa-plus ml-2"></i> إضافة تصنيف جديد
        </a>
    </div>

    @if(session('success'))
        <div class="mb-4 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 p-4 rounded-xl flex items-center gap-3">
            <i class="fa-solid fa-circle-check"></i>
            {{ session('success') }}
        </div>
    @endif

    @if($errors->any())
        <div class="mb-4 bg-red-50 dark:bg-red-900/20 text-red-600 p-4 rounded-xl flex flex-col gap-2">
            @foreach($errors->all() as $error)
                <div class="flex items-center gap-3"><i class="fa-solid fa-circle-exclamation"></i> {{ $error }}</div>
            @endforeach
        </div>
    @endif

    <!-- Search & Filter -->
    <div class="admin-card mb-6 p-4">
        <form action="{{ route('admin.categories.index') }}" method="GET" class="flex flex-col sm:flex-row gap-4">
            <div class="flex-1">
                <input type="text" name="search" value="{{ request('search') }}" placeholder="ابحث باسم التصنيف..." class="w-full rounded-xl border-gray-200 bg-gray-50/50 px-4 py-2.5 text-sm focus:border-blue-500 focus:ring-blue-500 dark:border-white/10 dark:bg-white/5 dark:text-white">
            </div>
            <div class="w-full sm:w-64">
                <select name="parent_id" class="w-full rounded-xl border-gray-200 bg-gray-50/50 px-4 py-2.5 text-sm focus:border-blue-500 focus:ring-blue-500 dark:border-white/10 dark:bg-white/5 dark:text-white">
                    <option value="">جميع التصنيفات الأب</option>
                    @foreach($parentCategories as $parent)
                        <option value="{{ $parent->id }}" {{ request('parent_id') == $parent->id ? 'selected' : '' }}>{{ $parent->title }}</option>
                    @endforeach
                </select>
            </div>
            <button type="submit" class="admin-btn bg-gray-800 text-white hover:bg-gray-700 dark:bg-white/10 dark:hover:bg-white/20">
                <i class="fa-solid fa-search ml-2"></i> بحث
            </button>
            @if(request()->has('search') || request()->has('parent_id'))
                <a href="{{ route('admin.categories.index') }}" class="admin-btn bg-red-50 text-red-600 hover:bg-red-100 dark:bg-red-900/20 dark:hover:bg-red-900/40">
                    <i class="fa-solid fa-times ml-2"></i> إلغاء
                </a>
            @endif
        </form>
    </div>

    <!-- Table -->
    <div class="admin-card overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-right text-sm">
                <thead>
                    <tr class="border-b border-gray-100 bg-gray-50/50 text-gray-500 dark:border-white/10 dark:bg-white/5 dark:text-gray-400">
                        <th class="px-6 py-4 font-medium"># ID</th>
                        <th class="px-6 py-4 font-medium">العنوان</th>
                        <th class="px-6 py-4 font-medium">التصنيف الأب</th>
                        <th class="px-6 py-4 font-medium">اللغة</th>
                        <th class="px-6 py-4 font-medium">عدد العناصر</th>
                        <th class="px-6 py-4 font-medium">الإجراءات</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-white/10">
                    @forelse($categories as $category)
                        <tr class="hover:bg-gray-50/50 dark:hover:bg-white/5 transition-colors">
                            <td class="px-6 py-4 font-semibold text-gray-900 dark:text-white">{{ $category->id }}</td>
                            <td class="px-6 py-4">
                                <span class="font-medium text-gray-800 dark:text-gray-200">{{ $category->title }}</span>
                            </td>
                            <td class="px-6 py-4">
                                @if($category->parent)
                                    <span class="inline-flex items-center gap-1.5 rounded-lg bg-blue-50 px-2.5 py-1 text-xs font-medium text-blue-600 dark:bg-blue-900/20 dark:text-blue-400">
                                        <i class="fa-solid fa-level-up-alt rotate-90"></i>
                                        {{ $category->parent->title }}
                                    </span>
                                @else
                                    <span class="text-gray-400 dark:text-gray-500">- أساسي -</span>
                                @endif
                            </td>
                            <td class="px-6 py-4">
                                <span class="uppercase font-medium text-gray-600 dark:text-gray-300">{{ $category->language }}</span>
                            </td>
                            <td class="px-6 py-4">
                                <span class="rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-800 dark:bg-white/10 dark:text-gray-200">
                                    {{ $category->items_count }}
                                </span>
                            </td>
                            <td class="px-6 py-4">
                                <div class="flex items-center gap-2">
                                    <a href="{{ route('admin.categories.edit', $category->id) }}" class="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 dark:bg-blue-900/20 dark:hover:bg-blue-900/40 transition-colors" title="تعديل">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </a>
                                    <form action="{{ route('admin.categories.destroy', $category->id) }}" method="POST" class="inline-block" onsubmit="return confirm('هل أنت متأكد من حذف هذا التصنيف؟');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="flex h-8 w-8 items-center justify-center rounded-lg bg-red-50 text-red-600 hover:bg-red-100 dark:bg-red-900/20 dark:hover:bg-red-900/40 transition-colors" title="حذف">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="px-6 py-8 text-center text-gray-500 dark:text-gray-400">لا توجد تصنيفات لعرضها.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        
        @if($categories->hasPages())
            <div class="border-t border-gray-100 p-4 dark:border-white/10">
                {{ $categories->withQueryString()->links() }}
            </div>
        @endif
    </div>
</x-admin-layout>
