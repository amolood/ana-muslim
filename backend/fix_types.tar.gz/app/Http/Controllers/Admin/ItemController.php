<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\AnaMuslimItem;

class ItemController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = AnaMuslimItem::with(['categories', 'authors']);

        if ($request->has('search')) {
            $search = $request->get('search');
            $query->where('title', 'like', "%{$search}%");
        }
        
        if ($request->has('type') && $request->get('type') !== '') {
            $query->where('type', $request->get('type'));
        }

        $items = $query->latest()->paginate(20);
        
        $types = AnaMuslimItem::select('type')->distinct()->pluck('type')
            ->reject(function ($type) {
                return is_numeric($type) || empty(trim($type));
            })->values();

        // Arabic translations mapping for known types
        $typeMap = [
            'audio' => 'صوتيات',
            'audios' => 'صوتيات',
            'video' => 'مرئيات',
            'videos' => 'مرئيات',
            'books' => 'كتب',
            'book' => 'كتاب',
            'articles' => 'مقالات',
            'article' => 'مقال',
            'fatwa' => 'فتاوى',
            'apps' => 'تطبيقات',
            'app' => 'تطبيق',
            'quran' => 'قرآن كريم',
            'khotab' => 'خطب',
            'poster' => 'بطاقات وملصقات',
            'favorites' => 'مفضلة'
        ];

        return view('admin.items.index', compact('items', 'types', 'typeMap'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $categories = \App\Models\AnaMuslimCategory::orderBy('title')->get();
        $authors = \App\Models\AnaMuslimAuthor::orderBy('title')->get();
        
        return view('admin.items.form', compact('categories', 'authors'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:500',
            'type' => 'nullable|string|max:100',
            'description' => 'nullable|string',
            'full_description' => 'nullable|string',
            'source_language' => 'nullable|string|max:10',
            'translated_language' => 'nullable|string|max:10',
            'importance_level' => 'nullable|string|max:255',
            'image' => 'nullable|string|max:500',
            'api_url' => 'nullable|url|max:500',
            'categories' => 'nullable|array',
            'categories.*' => 'exists:ana_muslim_categories,id',
            'authors' => 'nullable|array',
            'authors.*' => 'exists:ana_muslim_authors,id',
        ]);

        $item = AnaMuslimItem::create($validated);

        if ($request->has('categories')) {
            $item->categories()->sync($request->categories);
        }
        if ($request->has('authors')) {
            $item->authors()->sync($request->authors);
        }

        return redirect()->route('admin.items.index')->with('success', 'تم إضافة المادة بنجاح');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $item = AnaMuslimItem::findOrFail($id);
        $categories = \App\Models\AnaMuslimCategory::orderBy('title')->get();
        $authors = \App\Models\AnaMuslimAuthor::orderBy('title')->get();
        
        return view('admin.items.form', compact('item', 'categories', 'authors'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $item = AnaMuslimItem::findOrFail($id);

        $validated = $request->validate([
            'title' => 'required|string|max:500',
            'type' => 'nullable|string|max:100',
            'description' => 'nullable|string',
            'full_description' => 'nullable|string',
            'source_language' => 'nullable|string|max:10',
            'translated_language' => 'nullable|string|max:10',
            'importance_level' => 'nullable|string|max:255',
            'image' => 'nullable|string|max:500',
            'api_url' => 'nullable|url|max:500',
            'categories' => 'nullable|array',
            'categories.*' => 'exists:ana_muslim_categories,id',
            'authors' => 'nullable|array',
            'authors.*' => 'exists:ana_muslim_authors,id',
        ]);

        $item->update($validated);

        if ($request->has('categories')) {
            $item->categories()->sync($request->categories);
        } else {
            $item->categories()->detach();
        }

        if ($request->has('authors')) {
            $item->authors()->sync($request->authors);
        } else {
            $item->authors()->detach();
        }

        return redirect()->route('admin.items.index')->with('success', 'تم تحديث المادة بنجاح');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $item = AnaMuslimItem::findOrFail($id);
        
        // Detach relations
        $item->categories()->detach();
        $item->authors()->detach();
        $item->attachments()->delete();
        $item->locales()->delete();
        
        $item->delete();

        return redirect()->route('admin.items.index')->with('success', 'تم حذف المادة بنجاح');
    }
}
