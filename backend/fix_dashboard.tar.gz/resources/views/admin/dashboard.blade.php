<x-admin-layout>
    <!-- Welcome Banner Section -->
    <div class="mb-8 relative overflow-hidden rounded-2xl bg-gradient-to-r from-blue-700 to-indigo-800 p-8 text-white shadow-xl">
        <!-- Background decorative elements -->
        <div class="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-white/10 blur-3xl"></div>
        <div class="absolute -bottom-20 -left-20 h-64 w-64 rounded-full bg-blue-500/20 blur-3xl"></div>
        
        <div class="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
                <h1 class="text-3xl font-black mb-2 flex items-center gap-3">
                    <i class="fa-solid fa-hand-sparkles text-yellow-300"></i>
                    مرحباً بك في لوحة تحكم شبكة أنا المسلم
                </h1>
                <p class="text-blue-100 max-w-2xl text-lg leading-relaxed">
                    من هنا يمكنك إدارة كافة المواد العلمية، الصوتيات، المرئيات، الكتب، وتصانيفها بكل سهولة ويسر.
                </p>
            </div>
            <div class="flex shrink-0 items-center justify-center rounded-2xl bg-white/10 p-4 ring-1 ring-white/20 backdrop-blur-sm">
                <i class="fa-solid fa-mosque text-5xl text-white/90 drop-shadow-lg"></i>
            </div>
        </div>
    </div>

    <!-- 📊 Main Statistics Cards Grid -->
    <div class="mb-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <!-- Stat Card 1: Items -->
        <div class="admin-card overflow-hidden relative group hover:-translate-y-1 transition-all duration-300 shadow-sm hover:shadow-xl hover:shadow-blue-500/10">
            <div class="absolute inset-x-0 bottom-0 h-1.5 bg-gradient-to-r from-blue-500 to-indigo-500 group-hover:h-2 transition-all"></div>
            <div class="p-6">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-50 text-xl text-blue-600 dark:bg-blue-900/20 dark:text-blue-400">
                        <i class="fa-solid fa-photo-film"></i>
                    </div>
                    <span class="inline-flex items-center rounded-full bg-blue-50 px-2 py-1 text-xs font-medium text-blue-700 dark:bg-blue-500/10 dark:text-blue-400">
                        الأساس
                    </span>
                </div>
                <h3 class="text-4xl font-black text-gray-800 dark:text-white mb-1">{{ number_format($stats['items_count']) }}</h3>
                <p class="text-sm font-bold text-gray-500 dark:text-gray-400">إجمالي المواد والبرامج</p>
            </div>
            <a href="{{ route('admin.items.index') }}" class="block bg-gray-50/80 dark:bg-white/[0.02] py-3 px-6 text-xs font-bold text-blue-600 dark:text-blue-400 hover:bg-gray-100 dark:hover:bg-white/[0.05] transition-colors flex items-center justify-between">
                <span>إدارة المواد</span>
                <i class="fa-solid fa-arrow-left text-[10px]"></i>
            </a>
        </div>

        <!-- Stat Card 2: Categories -->
        <div class="admin-card overflow-hidden relative group hover:-translate-y-1 transition-all duration-300 shadow-sm hover:shadow-xl hover:shadow-emerald-500/10">
            <div class="absolute inset-x-0 bottom-0 h-1.5 bg-gradient-to-r from-emerald-500 to-teal-500 group-hover:h-2 transition-all"></div>
            <div class="p-6">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-50 text-xl text-emerald-600 dark:bg-emerald-900/20 dark:text-emerald-400">
                        <i class="fa-solid fa-folder-tree"></i>
                    </div>
                </div>
                <h3 class="text-4xl font-black text-gray-800 dark:text-white mb-1">{{ number_format($stats['categories_count']) }}</h3>
                <p class="text-sm font-bold text-gray-500 dark:text-gray-400">إجمالي التصنيفات</p>
            </div>
            <a href="{{ route('admin.categories.index') }}" class="block bg-gray-50/80 dark:bg-white/[0.02] py-3 px-6 text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:bg-gray-100 dark:hover:bg-white/[0.05] transition-colors flex items-center justify-between">
                <span>إدارة التصنيفات</span>
                <i class="fa-solid fa-arrow-left text-[10px]"></i>
            </a>
        </div>

        <!-- Stat Card 3: Authors -->
        <div class="admin-card overflow-hidden relative group hover:-translate-y-1 transition-all duration-300 shadow-sm hover:shadow-xl hover:shadow-amber-500/10">
            <div class="absolute inset-x-0 bottom-0 h-1.5 bg-gradient-to-r from-amber-500 to-orange-500 group-hover:h-2 transition-all"></div>
            <div class="p-6">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-50 text-xl text-amber-600 dark:bg-amber-900/20 dark:text-amber-400">
                        <i class="fa-solid fa-users-rectangle"></i>
                    </div>
                </div>
                <h3 class="text-4xl font-black text-gray-800 dark:text-white mb-1">{{ number_format($stats['authors_count']) }}</h3>
                <p class="text-sm font-bold text-gray-500 dark:text-gray-400">إجمالي المؤلفين والقراء</p>
            </div>
            <a href="{{ route('admin.authors.index') }}" class="block bg-gray-50/80 dark:bg-white/[0.02] py-3 px-6 text-xs font-bold text-amber-600 dark:text-amber-400 hover:bg-gray-100 dark:hover:bg-white/[0.05] transition-colors flex items-center justify-between">
                <span>إدارة المؤلفين</span>
                <i class="fa-solid fa-arrow-left text-[10px]"></i>
            </a>
        </div>

        <!-- Stat Card 4: Attachments -->
        <div class="admin-card overflow-hidden relative group hover:-translate-y-1 transition-all duration-300 shadow-sm hover:shadow-xl hover:shadow-purple-500/10">
            <div class="absolute inset-x-0 bottom-0 h-1.5 bg-gradient-to-r from-purple-500 to-pink-500 group-hover:h-2 transition-all"></div>
            <div class="p-6">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex h-12 w-12 items-center justify-center rounded-2xl bg-purple-50 text-xl text-purple-600 dark:bg-purple-900/20 dark:text-purple-400">
                        <i class="fa-solid fa-file-audio"></i>
                    </div>
                </div>
                <h3 class="text-4xl font-black text-gray-800 dark:text-white mb-1">{{ number_format($stats['attachments_count']) }}</h3>
                <p class="text-sm font-bold text-gray-500 dark:text-gray-400">ملفات المرفقات المتاحة</p>
            </div>
            <div class="block bg-gray-50/80 dark:bg-white/[0.02] py-3 px-6 text-xs font-bold text-gray-400 flex items-center justify-between">
                <span>مواد صوتية ومقروءة</span>
            </div>
        </div>
    </div>

    <!-- Quick Access & Recent Data Area -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Most Recent Items -->
        <div class="lg:col-span-2 space-y-4">
            <div class="flex items-center justify-between">
                <h3 class="text-lg font-bold text-gray-900 dark:text-white">
                    <i class="fa-solid fa-clock-rotate-left mr-1 text-blue-500"></i> أحدث المواد المضافة
                </h3>
                <a href="{{ route('admin.items.index') }}" class="text-sm font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300">
                    عرض الكل <i class="fa-solid fa-arrow-left text-[10px]"></i>
                </a>
            </div>
            
            <div class="admin-card overflow-hidden">
                <div class="divide-y divide-gray-100 dark:divide-white/10">
                    @forelse($stats['recent_items'] as $item)
                        <div class="p-4 flex items-center gap-4 hover:bg-gray-50/50 dark:hover:bg-white/[0.02] transition-colors group">
                            <!-- Icon/Image -->
                            <div class="shrink-0">
                                @if($item->image)
                                    <div class="h-12 w-12 overflow-hidden rounded-xl shadow-sm ring-1 ring-gray-900/10">
                                        <img src="{{ $item->image }}" alt="" class="h-full w-full object-cover">
                                    </div>
                                @else
                                    <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-50 to-blue-50 text-indigo-500 ring-1 ring-gray-900/5 dark:from-indigo-900/20 dark:to-blue-900/20 dark:ring-white/10">
                                        <i class="fa-solid fa-play text-lg opacity-70"></i>
                                    </div>
                                @endif
                            </div>
                            <!-- Info -->
                            <div class="flex-1 min-w-0">
                                <h4 class="truncate text-sm font-bold text-gray-900 dark:text-white mb-0.5">
                                    {{ $item->title }}
                                </h4>
                                <div class="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                                    <span class="inline-flex items-center gap-1 rounded bg-gray-100/80 px-1.5 py-0.5 font-medium dark:bg-white/10 text-[10px]">
                                        {{ $item->type ?? 'غير محدد' }}
                                    </span>
                                    <span>•</span>
                                    <span>{{ $item->created_at->diffForHumans() }}</span>
                                </div>
                            </div>
                            <!-- Action -->
                            <div class="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                                <a href="{{ route('admin.items.edit', $item->id) }}" class="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 dark:bg-blue-900/20 dark:hover:bg-blue-900/40" title="تعديل">
                                    <i class="fa-solid fa-pen text-xs"></i>
                                </a>
                            </div>
                        </div>
                    @empty
                        <div class="p-8 text-center text-sm text-gray-500 dark:text-gray-400">
                            لا توجد مواد مضافة بعد.
                        </div>
                    @endforelse
                </div>
            </div>
        </div>

        <!-- Quick Actions Sidebar -->
        <div class="space-y-4">
            <h3 class="text-lg font-bold text-gray-900 dark:text-white">
                <i class="fa-solid fa-bolt mr-1 text-amber-500"></i> إجراءات سريعة
            </h3>
            
            <div class="admin-card p-4 space-y-3">
                <a href="{{ route('admin.items.create') }}" class="group flex items-center justify-between rounded-xl p-3 hover:bg-gray-50 dark:hover:bg-white/5 transition-colors border border-transparent hover:border-gray-100 dark:hover:border-white/10">
                    <div class="flex items-center gap-3">
                        <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-100 text-blue-600 dark:bg-blue-900/40 dark:text-blue-400">
                            <i class="fa-solid fa-plus"></i>
                        </div>
                        <div class="text-sm font-bold text-gray-700 dark:text-gray-200">إضافة مادة جديدة</div>
                    </div>
                    <i class="fa-solid fa-chevron-left text-gray-300 text-xs group-hover:text-blue-500 transition-colors"></i>
                </a>

                <a href="{{ route('admin.categories.create') }}" class="group flex items-center justify-between rounded-xl p-3 hover:bg-gray-50 dark:hover:bg-white/5 transition-colors border border-transparent hover:border-gray-100 dark:hover:border-white/10">
                    <div class="flex items-center gap-3">
                        <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-100 text-emerald-600 dark:bg-emerald-900/40 dark:text-emerald-400">
                            <i class="fa-solid fa-folder-plus"></i>
                        </div>
                        <div class="text-sm font-bold text-gray-700 dark:text-gray-200">إنشاء تصنيف جديد</div>
                    </div>
                    <i class="fa-solid fa-chevron-left text-gray-300 text-xs group-hover:text-emerald-500 transition-colors"></i>
                </a>

                <a href="{{ route('admin.authors.create') }}" class="group flex items-center justify-between rounded-xl p-3 hover:bg-gray-50 dark:hover:bg-white/5 transition-colors border border-transparent hover:border-gray-100 dark:hover:border-white/10">
                    <div class="flex items-center gap-3">
                        <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-100 text-amber-600 dark:bg-amber-900/40 dark:text-amber-400">
                            <i class="fa-solid fa-user-plus"></i>
                        </div>
                        <div class="text-sm font-bold text-gray-700 dark:text-gray-200">إضافة مؤلف/قارئ</div>
                    </div>
                    <i class="fa-solid fa-chevron-left text-gray-300 text-xs group-hover:text-amber-500 transition-colors"></i>
                </a>
            </div>

            <div class="admin-card overflow-hidden bg-gradient-to-br from-gray-900 to-gray-800 text-white border-0 mt-6 shadow-xl">
                <div class="p-6">
                    <div class="mb-4 inline-flex items-center justify-center rounded-full bg-white/20 p-2 backdrop-blur-md">
                        <img src="https://ui-avatars.com/api/?name={{ Auth::user()->name }}&background=random&color=fff" alt="User" class="h-10 w-10 rounded-full ring-2 ring-white">
                    </div>
                    <h4 class="text-lg font-bold mb-1">مرحباً مجدداً، {{ explode(' ', Auth::user()->name)[0] }}!</h4>
                    <p class="text-xs text-gray-400 mb-6">لديك وصول كامل كمدير للنظام.</p>
                    
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button type="submit" class="w-full rounded-xl bg-white/10 py-2.5 px-4 text-sm font-bold text-white hover:bg-white/20 transition-colors flex items-center justify-center gap-2">
                            <i class="fa-solid fa-right-from-bracket"></i> تسجيل الخروج
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-admin-layout>
