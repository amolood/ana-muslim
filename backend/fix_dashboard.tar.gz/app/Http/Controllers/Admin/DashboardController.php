<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\AnaMuslimItem;
use App\Models\AnaMuslimCategory;
use App\Models\AnaMuslimAuthor;
use App\Models\AnaMuslimAttachment;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'items_count' => AnaMuslimItem::count(),
            'categories_count' => AnaMuslimCategory::count(),
            'authors_count' => AnaMuslimAuthor::count(),
            'attachments_count' => AnaMuslimAttachment::count(),
            'recent_items' => AnaMuslimItem::with('categories')->latest()->take(5)->get(),
        ];

        return view('admin.dashboard', compact('stats'));
    }
}
